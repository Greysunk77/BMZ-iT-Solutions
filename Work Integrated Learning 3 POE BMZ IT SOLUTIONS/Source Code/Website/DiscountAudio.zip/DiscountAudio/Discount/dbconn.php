<?php

//Creating a connect string
$conn = mysqli_connect('localhost', 'root', '', 'discountaudio', '3308') or die('connection failed');
