package com.example.bmzitsolutions;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class ContactUs extends AppCompatActivity {



        private EditText mName, mEmail, mNumber, mEnquiry;
        private Button mBook, mShow;

        private FirebaseDatabase db = FirebaseDatabase.getInstance();
        private DatabaseReference root = db.getReference().child("Users");
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_contact_us);

            mName = findViewById(R.id.Name);
            mEmail = findViewById(R.id.Email);
            mNumber = findViewById(R.id.Number);
            mEnquiry = findViewById(R.id.Enquiry);
            mBook = findViewById(R.id.btnBookSubmit);
            mShow = findViewById(R.id.btnShow);
            mBook.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String Name = mName.getText().toString();
                    String Email = mEmail.getText().toString();
                    String Number = mNumber.getText().toString();
                    String Enquiry = mEnquiry.getText().toString();


                    HashMap<String, String> userMap = new HashMap<>();

                    userMap.put("name",Name);
                    userMap.put("email",Email);
                    userMap.put("date",Number);
                    userMap.put("time",Enquiry);
                    root.push().setValue(userMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            Toast.makeText(ContactUs.this, "Data Saved", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            });

            mShow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(ContactUs.this, Show1.class);
                    startActivity(intent);
                }
            });

        }
    }