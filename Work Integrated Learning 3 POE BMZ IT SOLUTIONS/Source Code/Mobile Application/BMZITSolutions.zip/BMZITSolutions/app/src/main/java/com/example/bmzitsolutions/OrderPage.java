package com.example.bmzitsolutions;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import com.example.bmzitsolutions.Utils.spaceItemDecoration;
import com.example.bmzitsolutions.adapter.MyDrinkAdapter;
import com.example.bmzitsolutions.listener.ICartLoadListener;
import com.example.bmzitsolutions.listener.IDrinkLoadListener;
import com.example.bmzitsolutions.model.CartModel;
import com.example.bmzitsolutions.model.OrderModel;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.nex3z.notificationbadge.NotificationBadge;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class OrderPage extends AppCompatActivity implements IDrinkLoadListener, ICartLoadListener {

    @BindView(R.id.recycler_Drink)
    RecyclerView recyclerDrink;
    @BindView(R.id.mainLayout)
    RelativeLayout mainLayout;
    @BindView(R.id.badge)
    NotificationBadge badge;
    @BindView(R.id.btnCart)
    FrameLayout btnCart;

    IDrinkLoadListener drinkLoadListener;
    ICartLoadListener cartLoadListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_page);

        init();
        loadDrinkFromFirebase();
    }

    private void loadDrinkFromFirebase() {
        List<OrderModel> orderModels = new ArrayList<>();
        FirebaseDatabase.getInstance()
                .getReference("Drink")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.exists())
                        {
                            for (DataSnapshot drinkSnapshot:snapshot.getChildren())
                            {
                                OrderModel orderModel = drinkSnapshot.getValue(OrderModel.class);
                                orderModel.setKey(drinkSnapshot.getKey());
                                orderModels.add(orderModel);
                            }
                            drinkLoadListener.onDrinkLoadSuccess(orderModels);
                        }
                        else
                            drinkLoadListener.onDrinkLoadFailed("Can't find drink");
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
drinkLoadListener.onDrinkLoadFailed(error.getMessage());
                    }
                });

    }

    private  void init(){
        ButterKnife.bind(this);

        drinkLoadListener = this;
        cartLoadListener = this;

        GridLayoutManager gridLayoutManager = new GridLayoutManager(this,2);
        recyclerDrink.setLayoutManager(gridLayoutManager);
        recyclerDrink.addItemDecoration(new spaceItemDecoration());
    }

    @Override
    public void onDrinkLoadSuccess(List<OrderModel> orderModelList) {
        MyDrinkAdapter adapter = new MyDrinkAdapter(this,orderModelList);
        recyclerDrink.setAdapter(adapter);
    }

    @Override
    public void onDrinkLoadFailed(String message) {
        Snackbar.make(mainLayout,message,Snackbar.LENGTH_LONG).show();
    }

    @Override
    public void onCartLoadSuccess(List<CartModel> cartModelList) {

    }

    @Override
    public void onCartLoadFailed(String massage) {

    }
}