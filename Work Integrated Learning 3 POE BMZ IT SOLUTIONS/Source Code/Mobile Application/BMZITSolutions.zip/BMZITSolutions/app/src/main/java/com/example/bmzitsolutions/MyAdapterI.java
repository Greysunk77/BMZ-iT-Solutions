package com.example.bmzitsolutions;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapterI extends RecyclerView.Adapter<MyAdapterI.MyViewHolder>{


    ArrayList<ModelI> mList;
    Context context;

    public MyAdapterI(Context context , ArrayList<ModelI> mList) {
        this.mList = mList;
        this.context = context;

    }
    @NonNull
    @Override
    public MyAdapterI.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item , parent, false);
        return  new MyAdapterI.MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapterI.MyViewHolder holder, int position) {

        ModelI model = mList.get(position);
        holder.Name.setText(model.getName());
        holder.CarModel.setText(model.getCarModel());
        holder.CarPart.setText(model.getCarPart());
        holder.CarVINNumber.setText(model.getCarVINNumber());


    }
    @Override
    public int getItemCount()
    {
        return mList.size();
    }

    public  static  class MyViewHolder extends RecyclerView.ViewHolder{

        TextView Name, CarModel, CarPart, CarVINNumber;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            Name = itemView.findViewById(R.id.Name);
            CarModel = itemView.findViewById(R.id.CarModel);
            CarPart = itemView.findViewById(R.id.CarPart);
            CarVINNumber = itemView.findViewById(R.id.CarVINNumber);



        }
    }
}

