package com.example.bmzitsolutions.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

import com.bumptech.glide.Glide;
import com.example.bmzitsolutions.R;
import com.example.bmzitsolutions.model.OrderModel;

import java.util.List;

public class MyDrinkAdapter extends RecyclerView.Adapter<MyDrinkAdapter.MyDrinkViewHolder> {

    private Context context;
    private List<OrderModel> orderModelList;

    public MyDrinkAdapter(Context context, List<OrderModel> orderModelList) {
        this.context = context;
        this.orderModelList = orderModelList;
    }

    @NonNull
    @Override
    public MyDrinkViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyDrinkViewHolder(LayoutInflater.from(context)
                .inflate(R.layout.layout_drink_item,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyDrinkViewHolder holder, int position) {
        Glide.with(context)
                .load(orderModelList.get(position).getImage())
                .into(holder.imageView);
        holder.textPrice.setText(new StringBuilder("$").append(orderModelList.get(position).getPrice()));
        holder.textName.setText(new StringBuilder().append(orderModelList.get(position).getName()));
    }

    @Override
    public int getItemCount() {
        return orderModelList.size();
    }

    public class MyDrinkViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.imageView)
        ImageView imageView;
        @BindView(R.id.textName)
        TextView textName;
        @BindView(R.id.textPrice)
        TextView textPrice;

        private Unbinder unbinder;

         public MyDrinkViewHolder(@NonNull View itemView) {
            super(itemView);
            unbinder = ButterKnife.bind(this,itemView);
        }
    }
}
