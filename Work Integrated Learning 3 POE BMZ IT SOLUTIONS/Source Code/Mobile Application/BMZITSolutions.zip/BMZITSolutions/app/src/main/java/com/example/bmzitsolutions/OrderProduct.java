package com.example.bmzitsolutions;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class OrderProduct extends AppCompatActivity {

    private EditText mCarModel, mCarPart, mCarName, mCarVINNumber;
    private Button mBook, mShow;

    private FirebaseDatabase db = FirebaseDatabase.getInstance();
    private DatabaseReference root = db.getReference().child("Users");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_product);

        mCarModel = findViewById(R.id.CarModel);
        mCarPart = findViewById(R.id.CarPart);
        mCarName = findViewById(R.id.CarName);
        mCarVINNumber = findViewById(R.id.CarVINNumber);
        mBook = findViewById(R.id.btnOrderSubmit);
        mShow = findViewById(R.id.btnShow);
        mBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String CarName= mCarName.getText().toString();
                String CarModel = mCarModel.getText().toString();
                String CarPart = mCarPart.getText().toString();
                String CarVINNumber = mCarVINNumber.getText().toString();

                HashMap<String, String> userMap = new HashMap<>();

                userMap.put("name",CarName);
                userMap.put("model",CarModel);
                userMap.put("part",CarPart);
                userMap.put("VIN number",CarVINNumber);
                root.push().setValue(userMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Toast.makeText(OrderProduct.this, "Data Saved", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        mShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(OrderProduct.this, Show2.class);
                startActivity(intent);
            }
        });

    }
}