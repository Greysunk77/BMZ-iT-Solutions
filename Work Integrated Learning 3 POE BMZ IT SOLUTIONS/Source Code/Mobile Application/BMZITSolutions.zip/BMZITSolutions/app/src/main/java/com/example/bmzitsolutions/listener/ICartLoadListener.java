package com.example.bmzitsolutions.listener;

import com.example.bmzitsolutions.model.CartModel;

import java.util.List;
import  com.example.bmzitsolutions.model.CartModel;
public interface ICartLoadListener {
    void onCartLoadSuccess(List<CartModel>cartModelList);
    void onCartLoadFailed(String massage);
}
