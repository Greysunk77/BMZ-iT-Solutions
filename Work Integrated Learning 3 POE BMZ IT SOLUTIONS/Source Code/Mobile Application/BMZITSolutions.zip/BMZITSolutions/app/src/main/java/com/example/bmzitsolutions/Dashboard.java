package com.example.bmzitsolutions;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class Dashboard extends AppCompatActivity {

    private ImageView LinkService;
    private ImageView LinkSellAndBuy;
    private ImageView LinkOrder;
    private ImageView LinkMap;
    private ImageView LinkEmail;
    private ImageView LinkAdmin;
    private ImageView LinkSettings;
    private ImageView LinkProfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        LinkService = findViewById(R.id.Service);
        LinkSellAndBuy = findViewById(R.id.Sell);
        LinkOrder = findViewById(R.id.Order);
        LinkMap = findViewById(R.id.Map);
        LinkEmail = findViewById(R.id.Email);
        LinkProfile = findViewById(R.id.Profile);
        LinkAdmin = findViewById(R.id.Admin);
        LinkSettings = findViewById(R.id.Settings);

        LinkService.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Dashboard.this, Booking.class);
                startActivity(intent);
            }
        });
        LinkSellAndBuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Dashboard.this,OrderPage.class );
                startActivity(intent);
            }
        });

        LinkSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Dashboard.this,SettingsPage.class );
                startActivity(intent);
            }
        });

        LinkProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Dashboard.this,UserProfile.class );
                startActivity(intent);
            }
        });

        LinkEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Dashboard.this,OrderProduct.class );
                startActivity(intent);
            }
        });

        LinkMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Dashboard.this,Google_map.class );
                startActivity(intent);
            }
        });




    }
}