package com.example.bmzitsolutions;

public class ModelI {
    String Name,CarModel , CarPart, CarVINNumber;

    public String getName() {
        return Name;
    }

    public String getCarModel() {
        return CarModel;
    }

    public String getCarPart() {
        return CarPart;
    }

    public String getCarVINNumber() {
        return CarVINNumber;
    }
}

