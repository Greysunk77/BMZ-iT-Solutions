package com.example.bmzitsolutions;

public class Model {

    String Name, Email, Date,Time, Type;

    public String getName() {
        return Name;
    }

    public String getEmail() {
        return Email;
    }

    public String getDate() {
        return Date;
    }

    public String getTime() {
        return Time;
    }

    public String getType() {
        return Type;
    }

    public void setName(String name) {
        Name = name;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public void setDate(String date) {
        Date = date;
    }

    public void setTime(String time) {
        Time = time;
    }

    public void setType(String type) {
        Type = type;
    }
}
