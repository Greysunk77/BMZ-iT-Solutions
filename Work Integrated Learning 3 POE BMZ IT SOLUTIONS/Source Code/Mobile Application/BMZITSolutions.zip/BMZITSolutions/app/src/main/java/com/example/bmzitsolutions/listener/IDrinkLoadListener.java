package com.example.bmzitsolutions.listener;

import com.example.bmzitsolutions.model.OrderModel;

import java.util.List;
import com.example.bmzitsolutions.model.OrderModel;
public interface IDrinkLoadListener {
 void onDrinkLoadSuccess(List<OrderModel> orderModelList);
 void onDrinkLoadFailed(String message);
}
