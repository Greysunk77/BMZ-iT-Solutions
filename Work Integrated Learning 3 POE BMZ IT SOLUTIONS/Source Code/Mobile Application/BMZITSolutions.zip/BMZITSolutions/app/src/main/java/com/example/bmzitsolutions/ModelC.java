package com.example.bmzitsolutions;

public class ModelC {


    String Name, Email, Number, Enquiry;

    public String getName() {
        return Name;
    }

    public String getEmail() {
        return Email;
    }

    public String getNumber() {
        return Number;
    }

    public String getEnquiry() {
        return Enquiry;
    }


}
